#!/usr/bin/python3
"""universe-mcp: Universe OS tools for Claude Code (MCP over stdio, standard library only).

Claude Code starts this server itself (universe-claude passes --mcp-config). Every OS action goes through the running
Universe shell (`universe-ctl call`, an allow-list in universe_shell.CLAUDE_CALLS), so Claude gets no access that the
user's own desktop does not already have. The second brain (brein.py) is read and written directly.
"""
import base64
import json
import os
import socket
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import brein  # noqa: E402
import recoll_index  # noqa: E402

SOCKET = os.path.join(os.environ.get('XDG_RUNTIME_DIR', '/tmp'), 'universe-shell.sock')
PROTOCOL = '2025-06-18'
PLANETS = {'home': 'Thuiswereld (persoonlijke map)', 'apps': 'Applicaties', 'store': 'Softwarewinkel',
           'control': 'Controlecentrum', 'chat': 'Internet', 'games': 'Gamehal'}
TOOLS_FOR_RUN = ('files', 'terminal', 'monitor', 'software', 'control', 'pavucontrol', 'wdisplays', 'blueman-manager', 'network-editor')


class ToolError(Exception):
    pass


class MethodNotFound(Exception):
    pass


def shell(name, args=None, timeout=20):
    """Runs a page handler in the Universe shell and returns its result."""
    line = 'call %s %s\n' % (name, json.dumps(args or {}, ensure_ascii=False))
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect(SOCKET)
            s.sendall(line.encode())
            answer = s.makefile(encoding='utf-8').readline().strip()
    except OSError as error:
        raise ToolError('De Universe-shell is niet bereikbaar (%s).' % error)
    if answer.startswith('ok '):
        return json.loads(answer[3:])
    if answer == 'ok':
        return True
    raise ToolError(answer[len('fout: '):] if answer.startswith('fout: ') else answer or 'Geen antwoord van de shell')


def slim_app(a):
    return {'id': a['id'], 'naam': a['name'], 'omschrijving': a.get('comment', '')[:120]}


# ----- tools: name -> (description, input schema, function, read-only) -----
def t_overview(a):
    data = shell('config.get')
    planets = [{'id': p.get('id'), 'naam': p.get('name')} for p in (data.get('world') or {}).get('planets', [])] \
        or [{'id': k, 'naam': v} for k, v in PLANETS.items()]
    windows = [{'id': w.get('id'), 'titel': w.get('title'), 'programma': w.get('appName'), 'actief': w.get('activated'),
                'geminimaliseerd': w.get('minimized')} for w in shell('windows.list')]
    return {'gebruiker': data.get('user'), 'planeten': planets, 'vensters': windows,
            'instellingen': data.get('settings'), 'status': shell('status')}


def t_status(a):
    return shell('status')


def t_apps(a):
    q = (a.get('zoek') or '').strip().lower()
    apps = [slim_app(x) for x in shell('apps.list')]
    if q:
        apps = [x for x in apps if q in (x['naam'] + ' ' + x['omschrijving'] + ' ' + x['id']).lower()]
    return apps[:80]


def t_open_app(a):
    # Haiku sometimes sends {"naam": ...} instead of {"id": ...}: with an empty id every program matched and the first
    # one alphabetically (Atril) opened instead of Firefox (VM test, 11 Oct).
    app_id = str(a.get('id') or a.get('naam') or a.get('name') or a.get('programma') or '').strip()
    if not app_id:
        raise ToolError('Geef het programma op met "id" (uit apps_lijst) of een naam.')
    if not app_id.endswith('.desktop'):
        q = app_id.lower()
        apps = shell('apps.list')
        hits = [x for x in apps if q in (x['name'] + ' ' + x['id']).lower()]
        if not hits:
            raise ToolError('Geen programma gevonden voor "%s". Gebruik apps_lijst.' % app_id)
        # best match first: exact name or id, then names that start with the question
        hits.sort(key=lambda x: (x['name'].lower() != q and x['id'].lower() != q + '.desktop',
                                 not x['name'].lower().startswith(q), len(x['name'])))
        app_id = hits[0]['id']
    before = {w.get('id') for w in shell('windows.list')}
    shell('apps.launch', {'id': app_id})
    # Wait for its window (up to 8 s), so Claude does not take a screenshot before the program is there and conclude
    # that it failed (VM test, 11 Oct).
    stem = app_id[:-len('.desktop')].lower()
    for _ in range(16):
        time.sleep(0.5)
        new = [w for w in shell('windows.list') if w.get('id') not in before]
        if new:
            match = next((w for w in new if stem in (w.get('appId') or '').lower()), new[0])
            return 'Gestart: %s. Nieuw venster: "%s".' % (app_id, match.get('title') or match.get('appName') or '')
    return 'Gestart: %s (nog geen venster na 8 s; trage programma\'s hebben soms meer tijd nodig).' % app_id


def t_windows(a):
    return [{'id': w.get('id'), 'titel': w.get('title'), 'programma': w.get('appName'), 'actief': w.get('activated'),
             'geminimaliseerd': w.get('minimized')} for w in shell('windows.list')]


def t_window(a):
    action = a.get('actie')
    if action not in ('activeren', 'minimaliseren', 'sluiten'):
        raise ToolError('actie moet activeren, minimaliseren of sluiten zijn')
    name = {'activeren': 'windows.activate', 'minimaliseren': 'windows.minimize', 'sluiten': 'windows.close'}[action]
    shell(name, {'id': str(a.get('id'))})
    return 'Venster %s: %s' % (a.get('id'), action)


def t_desktop(a):
    shell('desktop.show')
    return 'Bureaublad getoond'


def t_planet(a):
    pid = a.get('id')
    if pid not in PLANETS:
        raise ToolError('Onbekende planeet; kies uit %s' % ', '.join(PLANETS))
    shell('world.open', {'id': pid})
    return 'Planeet geopend: %s' % PLANETS[pid]


def t_search(a):
    data = shell('search', {'q': str(a.get('zoek') or '')})
    return {'programmas': [slim_app(x) for x in data.get('apps', [])], 'bestanden': data.get('files', [])}


def t_open_path(a):
    path = os.path.expanduser(str(a.get('pad') or ''))
    if not os.path.exists(path):
        raise ToolError('Bestaat niet: %s' % path)
    shell('open.path', {'path': path})
    return 'Geopend: %s' % path


def t_tool(a):
    tool = a.get('hulpmiddel')
    if tool not in TOOLS_FOR_RUN:
        raise ToolError('Kies uit %s' % ', '.join(TOOLS_FOR_RUN))
    args = {'tool': tool}
    for key in ('page', 'path', 'search'):
        if a.get(key):
            args[key] = str(a[key])
    shell('run', args)
    return 'Geopend: %s' % tool


def t_volume(a):
    if a.get('dempen'):
        shell('volume.mute')
        return 'Geluid gedempt of weer aan'
    level = max(0, min(100, int(a.get('niveau', 50))))
    shell('volume.set', {'level': level})
    return 'Volume: %d%%' % level


POWER = {'vergrendelen': 'lock', 'afmelden': 'logout', 'opnieuw_opstarten': 'reboot', 'afsluiten': 'poweroff',
         'slaapstand': 'suspend'}


def t_power(a):
    """Through the shell, exactly like the buttons: the lock and shutdown animations always play (Axel, 13 Oct). The
    answer comes at once; the shell starts the animation a moment later and closes the Claude panel first."""
    action = POWER.get(a.get('actie'))
    if not action:
        raise ToolError('actie moet een van deze zijn: ' + ', '.join(POWER))
    shell('claude.power', {'action': action})
    return {'lock': 'Het scherm wordt vergrendeld (met de animatie).', 'logout': 'Je wordt afgemeld.',
            'reboot': 'De computer start opnieuw op.', 'poweroff': 'De computer wordt afgesloten.',
            'suspend': 'De computer gaat in slaapstand.'}[action]


def t_audio(a):
    if a.get('id') is None:
        return shell('audio.outputs')
    return shell('audio.select', {'id': a.get('id'), 'name': a.get('naam')})


def t_browser(a):
    if not a.get('id'):
        return shell('browser.list')
    return shell('browser.select', {'id': a.get('id')})


def t_updates(a):
    name = {'status': 'updates.status', 'controleren': 'updates.refresh', 'installeren': 'updates.install'}.get(a.get('actie') or 'status')
    if not name:
        raise ToolError('actie moet status, controleren of installeren zijn')
    return shell(name, timeout=60)


def t_desktop_file(a):
    action, path = a.get('actie'), str(a.get('pad') or '')
    if action == 'hernoemen':
        return shell('desktop.rename', {'path': path, 'name': a.get('naam')})
    if action == 'prullenbak':
        shell('desktop.trash', {'path': path})
        return 'Naar de prullenbak verplaatst: %s' % path
    if action == 'openen':
        shell('desktop.launch', {'path': path})
        return 'Geopend: %s' % path
    raise ToolError('actie moet hernoemen, prullenbak of openen zijn')


# Security stays with the user (Axel, 13 Oct): Claude may not switch the automatic lock off or make it longer.
SECURITY_SETTINGS = {'lockMinutes'}


def t_setting(a):
    if a.get('sleutel') in SECURITY_SETTINGS:
        raise ToolError('Dit is een beveiligingsinstelling; die verandert de gebruiker zelf in het Controlecentrum.')
    shell('config.set', {'key': a.get('sleutel'), 'value': a.get('waarde')})
    return 'Instelling %s = %s' % (a.get('sleutel'), json.dumps(a.get('waarde')))


def t_screenshot(a):
    """A small JPEG of the whole screen, so Claude can see what the user sees."""
    try:
        png = subprocess.run(['grim', '-s', '0.5', '-l', '1', '-'], capture_output=True, timeout=10, check=True).stdout
    except (OSError, subprocess.SubprocessError) as error:
        raise ToolError('Schermafbeelding mislukt: %s' % error)
    # Debian's grim has no JPEG support; GdkPixbuf makes a JPEG that is several times smaller than the PNG.
    try:
        import gi
        gi.require_version('GdkPixbuf', '2.0')
        from gi.repository import GdkPixbuf
        loader = GdkPixbuf.PixbufLoader.new_with_type('png')
        loader.write(png)
        loader.close()
        ok, jpeg = loader.get_pixbuf().save_to_bufferv('jpeg', ['quality'], ['75'])
        if ok:
            return {'_image': base64.b64encode(jpeg).decode(), '_mime': 'image/jpeg'}
    except Exception:  # noqa: BLE001 - the PNG still works
        pass
    return {'_image': base64.b64encode(png).decode(), '_mime': 'image/png'}


def t_notify(a):
    subprocess.run(['notify-send', '-a', 'Claude', str(a.get('titel') or 'Claude')[:120], str(a.get('tekst') or '')[:500]], timeout=5)
    return 'Melding getoond'


def t_find_files(a):
    found = recoll_index.search(a.get('zoek') or '', a.get('max') or 20)
    if found is None:  # no Recoll: the quick name search of the shell
        return {'bron': 'bestandsnamen', 'resultaten': shell('search.files', {'q': str(a.get('zoek') or '')})}
    return {'bron': 'recoll (inhoud van bestanden)', 'resultaten': found}


def t_timeline(a):
    return brein.timeline(a.get('dagen') or 7, a.get('soort'), a.get('max') or 100)


def t_desktop_files(a):
    return shell('desktop.list')


def t_remember(a):
    return {'id': brein.remember(a.get('tekst'), a.get('soort') or 'notitie', a.get('labels') or '')}


def t_recall(a):
    return brein.recall(a.get('zoek') or '', a.get('soort'), a.get('max') or 20)


def t_brain_update(a):
    return brein.update(a.get('id'), a.get('tekst'))


def t_forget(a):
    return brein.forget(a.get('id'))


S = lambda props, req=(): {'type': 'object', 'properties': props, 'required': list(req)}  # noqa: E731
STR = {'type': 'string'}

TOOLS = {
    'overzicht': ('What the user sees now: planets of the space world, open windows, settings and system status. '
                  'Call this first when a request is about the screen.', S({}), t_overview, True),
    'status': ('Network, volume, battery and notifications.', S({}), t_status, True),
    'apps_lijst': ('Installed programs (id, name, description). Optional filter "zoek".', S({'zoek': STR}), t_apps, True),
    'app_openen': ('Start a program. Put its .desktop id (from apps_lijst) or (part of) its name in "id".', S({'id': STR}, ['id']), t_open_app, False),
    'vensters': ('Open windows with their id.', S({}), t_windows, True),
    'venster': ('Activate, minimize or close a window (id from vensters).',
                S({'id': STR, 'actie': {'type': 'string', 'enum': ['activeren', 'minimaliseren', 'sluiten']}}, ['id', 'actie']), t_window, False),
    'bureaublad_tonen': ('Minimize all windows to show the 3D desktop (the space world).', S({}), t_desktop, False),
    'planeet_openen': ('Fly to a planet in the space world: ' + ', '.join('%s = %s' % kv for kv in PLANETS.items()) + '.',
                       S({'id': {'type': 'string', 'enum': list(PLANETS)}}, ['id']), t_planet, False),
    'zoeken': ('Search programs and files (like the start menu search).', S({'zoek': STR}, ['zoek']), t_search, True),
    'pad_openen': ('Open a file or folder with its default program (~ allowed).', S({'pad': STR}, ['pad']), t_open_path, False),
    'hulpmiddel_openen': ('Open a system tool: ' + ', '.join(TOOLS_FOR_RUN) + '. For control, "page" picks a page; '
                          'for files, "path"; for software, "search".',
                          S({'hulpmiddel': {'type': 'string', 'enum': list(TOOLS_FOR_RUN)}, 'page': STR, 'path': STR, 'search': STR},
                            ['hulpmiddel']), t_tool, False),
    'volume': ('Set the volume (niveau 0-100) or toggle mute (dempen: true).',
               S({'niveau': {'type': 'integer', 'minimum': 0, 'maximum': 100}, 'dempen': {'type': 'boolean'}}), t_volume, False),
    'instelling': ('Change a Universe setting. Keys: animations (full/reduced/off), uiScale (50-300), textScale (75-250), '
                   'screenOffMinutes (0-240), naturalScroll, tapToClick, buddy (true/false), sounds (true/false), '
                   'pointerSpeed (-1..1). Security settings (automatic lock) are not allowed.',
                   S({'sleutel': STR, 'waarde': {}}, ['sleutel', 'waarde']), t_setting, False),
    'energie': ('Lock the screen, log out, restart, shut down or sleep. ALWAYS use this tool for these, never a shell '
                'command: it plays the Universe animations and returns at once. Lock and sleep need no confirmation; '
                'ask before logout, restart or shutdown unless the user asked for exactly that.',
                S({'actie': {'type': 'string', 'enum': list(POWER)}}, ['actie']), t_power, False),
    'geluidsuitgang': ('Sound outputs (speakers, headphones, HDMI). Without id: list them; with id + naam: make it the default.',
                       S({'id': {'type': 'integer'}, 'naam': STR}), t_audio, False),
    'standaardbrowser': ('Web browsers. Without id: list them and the default; with id: make it the default browser.',
                         S({'id': STR}), t_browser, False),
    'updates': ('System updates: status, controleren (check now) or installeren (check + install; the computer then '
                'restarts after 2 minutes, tell the user).', S({'actie': {'type': 'string', 'enum': ['status', 'controleren', 'installeren']}}),
                t_updates, False),
    'bureaublad_bestand': ('A file or shortcut on the desktop (pad from bureaublad_bestanden): hernoemen (with naam), '
                           'prullenbak (move to trash; ask first) or openen.',
                           S({'actie': {'type': 'string', 'enum': ['hernoemen', 'prullenbak', 'openen']}, 'pad': STR, 'naam': STR},
                             ['actie', 'pad']), t_desktop_file, False),
    'schermafbeelding': ('Look at the screen: returns a half-size image of what the user sees now.', S({}), t_screenshot, True),
    'melding': ('Show a desktop notification.', S({'titel': STR, 'tekst': STR}, ['titel']), t_notify, False),
    'bureaublad_bestanden': ('Files and shortcuts on the desktop (Bureaublad folder).', S({}), t_desktop_files, True),
    'bestanden_doorzoeken': ('Second brain: full-text search INSIDE the documents of the user (PDF, office, text) with Recoll; '
                             'query syntax like a web search. Returns paths with a short excerpt.',
                             S({'zoek': STR, 'max': {'type': 'integer'}}, ['zoek']), t_find_files, True),
    'tijdlijn': ('Second brain: what the user opened recently (programs and files), newest first.',
                 S({'dagen': {'type': 'integer'}, 'soort': {'type': 'string', 'enum': ['app', 'file']}, 'max': {'type': 'integer'}}), t_timeline, True),
    'brein_onthouden': ('Second brain (local, private): remember something for later conversations. soort: voorkeur '
                        '(how the user likes things), feit (about the user or computer) or notitie.',
                        S({'tekst': STR, 'soort': {'type': 'string', 'enum': list(brein.KINDS)}, 'labels': STR}, ['tekst']), t_remember, False),
    'brein_zoeken': ('Second brain: search memories (empty "zoek" = most recent). Check preferences at the start of a task.',
                     S({'zoek': STR, 'soort': {'type': 'string', 'enum': list(brein.KINDS)}, 'max': {'type': 'integer'}}), t_recall, True),
    'brein_bijwerken': ('Second brain: replace the text of a memory.', S({'id': {'type': 'integer'}, 'tekst': STR}, ['id', 'tekst']), t_brain_update, False),
    'brein_vergeten': ('Second brain: delete a memory.', S({'id': {'type': 'integer'}}, ['id']), t_forget, False),
}


def name_fallback(tool, args):
    """app_openen also accepts a name under another key (Haiku used 'naam'); other tools need their exact keys."""
    if tool == 'app_openen' and any(args.get(k) for k in ('naam', 'name', 'programma')):
        return True
    return None


def content(result):
    if isinstance(result, dict) and '_image' in result:
        return [{'type': 'image', 'data': result['_image'], 'mimeType': result['_mime']}]
    text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False, indent=1)
    return [{'type': 'text', 'text': text}]


def handle(msg):
    method, params = msg.get('method'), msg.get('params') or {}
    if method == 'initialize':
        return {'protocolVersion': params.get('protocolVersion') or PROTOCOL, 'capabilities': {'tools': {}},
                'serverInfo': {'name': 'universe', 'version': '1.0'},
                'instructions': 'Tools to operate Universe OS (the user\'s desktop) and a private local second brain.'}
    if method == 'ping':
        return {}
    if method == 'tools/list':
        return {'tools': [{'name': name, 'description': d, 'inputSchema': schema,
                           'annotations': {'readOnlyHint': ro}} for name, (d, schema, fn, ro) in TOOLS.items()]}
    if method == 'tools/call':
        tool = TOOLS.get(params.get('name'))
        if not tool:
            return {'content': [{'type': 'text', 'text': 'Onbekend hulpmiddel'}], 'isError': True}
        args = params.get('arguments') or {}
        missing = [k for k in tool[1].get('required', []) if k not in args]
        if missing and name_fallback(params.get('name'), args) is None:
            return {'content': [{'type': 'text', 'text': 'Ontbrekend: %s (gekregen: %s). Gebruik precies deze namen: %s.' % (
                ', '.join(missing), ', '.join(args) or 'niets', ', '.join(tool[1].get('properties', {})))}], 'isError': True}
        try:
            return {'content': content(tool[2](args))}
        except Exception as error:  # every failure is a tool result Claude can read, not a protocol error
            return {'content': [{'type': 'text', 'text': str(error) or error.__class__.__name__}], 'isError': True}
    raise MethodNotFound(method)


def main():
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            msg = json.loads(raw)
        except ValueError:
            continue
        if 'id' not in msg:
            continue  # notifications (initialized, cancelled) need no answer
        try:
            reply = {'jsonrpc': '2.0', 'id': msg['id'], 'result': handle(msg)}
        except MethodNotFound:
            reply = {'jsonrpc': '2.0', 'id': msg['id'], 'error': {'code': -32601, 'message': 'Method not found'}}
        except Exception as error:  # never crash: Claude Code would lose all tools
            reply = {'jsonrpc': '2.0', 'id': msg['id'], 'error': {'code': -32603, 'message': str(error)}}
        sys.stdout.write(json.dumps(reply, ensure_ascii=False) + '\n')
        sys.stdout.flush()


if __name__ == '__main__':
    main()
