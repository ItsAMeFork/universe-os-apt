import {call,on,applySettings,motionAllowed,toast,h} from './api.js';
// The simple world (0.2.28): every program as a plain button. Only things that cannot fail to draw.
const list=document.getElementById('apps');
// v4: dezelfde 220 ms atmosfeerfeedback, op de bestaande eenvoudige appknoppen; geen extra tekenlus.
const hoverStyle=document.createElement('style');
hoverStyle.textContent=`
.app{position:relative;transition:background .22s var(--motion-exit),border-color .22s var(--motion-exit),box-shadow .22s var(--motion-exit),transform .22s var(--motion-exit)}
.app::after{content:'';position:absolute;left:50%;top:4px;width:64px;height:64px;margin-left:-32px;border:1px solid #bdefff99;border-radius:50%;pointer-events:none;
 background:radial-gradient(circle,transparent 60%,#a6eaff12 69%,transparent 74%);opacity:0;transform:scale(.98);
 transition:opacity .22s var(--motion-exit),transform .22s var(--motion-exit)}
.app:is(:hover,:focus-visible,.selected){border-color:#c5edff66;background:#162335;box-shadow:0 0 20px #baffee33;transition-timing-function:var(--motion-enter)}
.app:is(:hover,:focus-visible,.selected)::after{opacity:1;transform:scale(1.03);transition-timing-function:var(--motion-enter)}
html:is(.reduce-motion,.no-motion) .app{transform:none!important}
html:is(.reduce-motion,.no-motion) .app::after{transition:none!important;transform:none!important}
@media(prefers-reduced-motion:reduce){
 .app{transition:background .12s,border-color .12s,box-shadow .12s;transform:none!important}
 .app::after{transition:none!important;transform:none!important}}
`;
document.head.append(hoverStyle);
function selectApp(e){
 const b=e.target.closest('.app');if(!b||!list.contains(b))return;
 for(const app of list.children)app.classList.toggle('selected',app===b);
}
list.addEventListener('pointerdown',selectApp);
list.addEventListener('focusin',selectApp);
let config={},scene=null,sceneEnd=0,closing=false,epoch=0;
async function load(){
 let apps=[];
 try{apps=await call('apps.list');}catch(e){toast('Programma\'s laden mislukt: '+e.message);}
 apps=[...apps].sort((a,b)=>String(a.name).localeCompare(String(b.name),'nl'));
 list.replaceChildren(...apps.map(a=>{
  const b=h('button',{class:'app',type:'button',role:'listitem',title:a.name},a.icon?h('img',{src:a.icon,alt:''}):h('span',{class:'ph','aria-hidden':'true'}),h('span',{},a.name));
  b.addEventListener('click',()=>{
   const r=b.getBoundingClientRect();
   if(motionAllowed(config.settings||{}))import('./motion.js').then(({launchFeedback})=>launchFeedback(b)).catch(()=>{});
   // Ook de eenvoudige wereld geeft het echte klikpunt aan het bestaande vensterportaal.
   call('apps.launch',{id:a.id,bron:'world',x:r.left+r.width/2,y:r.top+r.height/2}).catch(e=>toast(e.message));
  });
  return b;
 }));
}
document.getElementById('diag').addEventListener('click',()=>call('apps.launch',{id:'universe-diagnose.desktop'}).then(()=>toast('Diagnose wordt gemaakt; het pad verschijnt in het venster.')).catch(e=>toast(e.message)));
(async()=>{
 try{const c=await call('config.get');config=c;applySettings({...c.settings,colors:c.world?.colors});}catch{}
 await load();
 window.__universePageReady?.();
 call('world.ready',{milliseconds:performance.now(),lite:true}).catch(()=>{});
})();
on('apps-changed',load);

// The fallback desktop uses the same scene, original planets and shell-owned deadline. Loaded only when needed: a
// broken scene module must never take the simple desktop down with it.
on('launch-countdown',async({seconds=10,runup=0,elapsed=0,version=''}={})=>{
 if(scene||closing)return;
 const received=performance.now();
 sceneEnd=received+(runup+seconds-elapsed)*1000;
 scene={stop(){}}; // claimed at once: a second message while the module loads starts nothing
 try{
  const {startUpdateScene}=await import('./meteoriet.js');
  if(!scene)return; // stopped while loading
  scene=startUpdateScene({host:document.body,seconds,runup,elapsed:elapsed+(performance.now()-received)/1000,version,
   reduced:!motionAllowed(config.settings||{}),planets:config.world?.planets||[]});
 }catch(e){scene=null;console.error('update-scene',e);toast('Opnieuw opstarten over '+seconds+' seconden.');}
});
on('logout-begin',async({action='logout'}={})=>{
 if(closing)return;
 closing=true;const token=++epoch;
 if(scene&&action==='reboot'&&performance.now()>=sceneEnd-1000){
  await new Promise(r=>setTimeout(r,Math.max(0,sceneEnd+1900-performance.now())));
 }else{scene?.stop();scene=null;await kernBeweging(true);}
 if(token===epoch)call('logout.finish').catch(e=>toast(e.message));
});
on('logout-error',message=>{epoch++;scene?.stop();scene=null;kernVlucht?.abort();kernVlucht=null;kern?.remove();kern=null;closing=false;toast('Afmelden mislukt: '+message);});

// Lock / unlock (0.3.6, Axel 29 Oct: "zorg ervoor dat dit altijd werkt, zowel de lichte modus als de normale"): as in
// the space world (world.js), the screen goes into the glowing core when locking (kern.png, the first picture of the
// login screen) and comes out of it after unlocking. Before, this page ignored both: universe-lock waited 6 s for
// lock.ready and the world stayed above the windows for 4 s after unlocking. Loaded only when needed, like the scene.
let kern=null,locked=false,kernVlucht=null;
async function kernBeweging(uit){
 kernVlucht?.abort();const vlucht=new AbortController();kernVlucht=vlucht;
 try{
  const [{drawCore,lensStreak},{speelBeweging,beweging},{bigEarth,loginEarthPx}]=await Promise.all([import('./explode.js'),import('./opstartvlucht.js'),import('./space.js')]);
  if(vlucht.signal.aborted)return false;
  const W=innerWidth,H=innerHeight;
  if(!kern){kern=document.createElement('canvas');kern.setAttribute('aria-hidden','true');kern.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:100;pointer-events:none';document.body.append(kern);}
  kern.width=Math.round(W/2);kern.height=Math.round(H/2); // soft light: half resolution is enough
  const c=kern.getContext('2d');c.setTransform(.5,0,0,.5,0,0);
  // Eén aardebeeld en vaste deeltjes, vooraf berekend. Dezelfde duur en kernkrommen als animateWorld.
  const D=loginEarthPx(),big=Math.max(W,H);let aarde=null;
  // Een mislukte aardetextuur mag de kern van de noodweergave niet meenemen.
  if(motionAllowed(config.settings||{})){try{aarde=bigEarth(D);}catch(e){console.error('aarde',e);}}
  const deeltjes=Array.from({length:240},(_,i)=>{let seed=(i*7919+17)%233280;const r=()=>(seed=(seed*9301+49297)%233280)/233280;
   const a=r()*Math.PI*2;return{ca:Math.cos(a),sa:Math.sin(a),speed:.25+r()*1.05,w:.8+r()*2.2,hot:r()<.5};});
  const teken=t=>{
   if(vlucht.signal.aborted)return;
   c.clearRect(0,0,W,H);
   const kernP=uit?beweging(Math.max(0,(t-.62)/.38),'uit'):1-beweging(Math.min(1,t/.3),'in');
   const bolP=uit?1-kernP:beweging(Math.min(1,t/.25),'in')*(1+.02*Math.sin(Math.PI*Math.min(1,t/.4)));
   if(aarde&&bolP>0){const zicht=uit?beweging(Math.min(1,t/.4),'in'):1-beweging(Math.max(0,(t-.4)/.6));
    c.save();c.globalAlpha=zicht;c.drawImage(aarde,W/2-D*bolP/2,H/2-D*bolP/2,D*bolP,D*bolP);c.restore();}
   if(kernP>0)drawCore(c,W,H,uit?2.4-1.4*kernP:1+2.2*(1-kernP),kernP);
   const fase=uit?beweging(t):beweging(Math.min(1,t/.55),'in'),vorige=uit?beweging(Math.min(1,t+.06)):beweging(Math.max(0,Math.min(1,t/.55)-.06),'in');
   const k=uit?1-fase:fase,k0=uit?1-vorige:vorige,licht=Math.sin(Math.PI*t)*.7;
   c.lineCap='round';
   for(const s of deeltjes){const d=s.speed*big*k,d0=s.speed*big*k0;c.strokeStyle=`rgba(${s.hot?'255,220,170':'150,230,255'},${licht.toFixed(3)})`;c.lineWidth=s.w;
    c.beginPath();c.moveTo(W/2+s.ca*d0,H/2+s.sa*d0*.7);c.lineTo(W/2+s.ca*d,H/2+s.sa*d*.7);c.stroke();}
   lensStreak(c,W,H/2,Math.sin(Math.PI*t)*.45);
  };
  if(motionAllowed(config.settings||{}))await speelBeweging(uit?2300:2800,teken,{signal:vlucht.signal});
  if(kernVlucht!==vlucht||vlucht.signal.aborted)return false;
  c.clearRect(0,0,W,H);if(uit)drawCore(c,W,H);
 }catch(e){console.error('vergrendelen',e);}
 if(kernVlucht===vlucht){kernVlucht=null;if(!uit){kern?.remove();kern=null;}}
 return !vlucht.signal.aborted;
}
on('lock-begin',async()=>{if(locked)return;locked=true;if(await kernBeweging(true)!==false&&locked)call('lock.ready').catch(()=>{});});
on('unlock',async()=>{if(!locked)return;locked=false;if(await kernBeweging(false)!==false&&!locked)call('unlock.done').catch(()=>{});});
