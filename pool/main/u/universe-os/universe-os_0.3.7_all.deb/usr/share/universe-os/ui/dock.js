import {call,on,applySettings,toast,h,icon} from './api.js';
import {surfaceMotion,revealItems,launchFeedback,easing} from './motion.js';
// Taskbar (Axel, 10 Oct: "like Windows, in the style of the concept photos"). The start menu is its own surface
// (start.html); the start button only asks the shell to show or hide it.
// Left the start button (Universe planet), then the user's own buttons (layout.dock) and every open window that is
// not one of them. A dot shows that a program is open; clicking an open program brings its window forward.
// Everything except the start button is optional: drag to reorder, right click to remove.
// The surface grows upwards while a small popup menu is open.

const DOCK_HEIGHT=64;
// match: lower-case parts of the Wayland app id that belong to this program.
const BUILTIN={
 space:{name:'Bureaublad tonen',iconName:'display',match:[],click:()=>call('desktop.show')},
 files:{name:'Bestanden',desktop:'thunar.desktop',iconName:'folder',match:['thunar'],click:()=>call('run',{tool:'files'})},
 browser:{name:'Internet',iconName:'globe',match:['firefox','chrome','chromium','epiphany','brave'],click:openBrowser},
 terminal:{name:'Terminal',desktop:'xfce4-terminal.desktop',iconName:'windows',match:['xfce4-terminal','terminal'],click:()=>call('run',{tool:'terminal'})},
 store:{name:'Softwarewinkel',desktop:'org.gnome.Software.desktop',iconName:'store',match:['gnome.software','gnome-software'],click:()=>call('run',{tool:'software'})},
 control:{name:'Controlecentrum',iconName:'gear',match:['universeos.controlcenter'],click:()=>call('run',{tool:'control'})},
};
let windows=[],apps=[],browserIcon=null,layout={dock:Object.keys(BUILTIN)},popup=null,startOpen=false;
const bar=h('nav',{class:'dock','aria-label':'Taakbalk'});
document.body.append(bar);

async function openBrowser(){
 const b=await call('browser.list');
 if(b.default)return call('apps.launch',{id:b.default});
 return call('world.open',{id:'chat'}); // no default yet: the Internet room lets you choose one
}
/** The program behind a taskbar entry ('files', or 'app:org.gnome.Calculator.desktop'). */
function entry(key){
 if(BUILTIN[key]){
  const b=BUILTIN[key];
  return {key,...b,img:key==='browser'?browserIcon:null}; // own icons for the fixed buttons, one style (23 Oct)
 }
 const id=key.slice(4),a=apps.find(x=>x.id===id),base=id.replace(/\.desktop$/,'').toLowerCase();
 return {key,name:a?.name||base,img:a?.icon,iconName:'grid',match:[base,base.split('.').pop()],click:()=>call('apps.launch',{id})};
}
const owns=(e,w)=>e.match.some(m=>m&&(w.appId||'').toLowerCase().includes(m));
const act=(fn)=>Promise.resolve().then(fn).catch(e=>toast(e.message));

function button({name,img,iconName,cls='',open,active,onClick}){
 const b=h('button',{class:`item ${cls}${open?' open':''}${active?' active':''}`,type:'button',title:name,
  'aria-label':name+(active?' (actief)':open?' (geopend)':''),'aria-current':active?'true':null},img?h('img',{src:img,alt:''}):icon(iconName),h('span',{class:'dot','aria-hidden':'true'}));
 b._onClick=onClick;
 b.addEventListener('click',()=>{
  if(b.dataset.dragged){delete b.dataset.dragged;return;}
  hideLabel();
  if(!b.classList.contains('open')){
   const token=(b._launchToken||0)+1;b._launchToken=token;
   launchFeedback(b);b.classList.add('launching');
   surfaceMotion(b,true,{duration:720,frames:[{transform:'translateY(0)',offset:0},{transform:'translateY(-4px) scale(1.03)',offset:.3},{transform:'translateY(1px)',offset:.8},{transform:'translateY(0)',offset:1}]}).then(()=>{if(token===b._launchToken)b.classList.remove('launching');});
  }
  act(()=>b._onClick());
 });
 labelled(b);
 return b;
}
function render(){
 const old=new Map([...bar.children].filter(b=>b.dataset.motionKey).map(b=>[b.dataset.motionKey,b]));
 const before=new Map([...old].map(([key,b])=>[key,b.getBoundingClientRect()]));
 const focused=document.activeElement;
 const startButton=h('button',{class:'item start-button'+(startOpen?' active':''),type:'button',title:'Start','aria-label':'Start','aria-expanded':String(startOpen),
  html:'<svg viewBox="0 0 32 32" aria-hidden="true"><defs><radialGradient id="sb" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ffd2a0"/><stop offset=".55" stop-color="#ff8a3d"/><stop offset="1" stop-color="#a33c10"/></radialGradient></defs><circle cx="16" cy="16" r="8.5" fill="url(#sb)"/><ellipse cx="16" cy="16" rx="14" ry="5" fill="none" stroke="#85ffe3" stroke-width="1.6" transform="rotate(-18 16 16)"/></svg>'});
 startButton.addEventListener('click',()=>call('start.toggle').catch(e=>toast(e.message)));
 startButton.dataset.motionKey='start';labelled(startButton);
 const entries=layout.dock.map(entry);
 const pinned=entries.map(e=>{
  const mine=windows.filter(w=>owns(e,w));
  const b=button({name:e.name,img:e.img,iconName:e.iconName,open:mine.length>0,active:mine.some(w=>w.activated),
   onClick:()=>mine.length?call('windows.activate',{id:mine[0].id}):e.click()});
  reorderable(b,e.key);
  b.dataset.motionKey=e.key;
  b._menuEntries=()=>[
   {label:mine.length?'Naar voren halen':'Openen',run:()=>mine.length?call('windows.activate',{id:mine[0].id}):e.click()},
   ...(e.key==='browser'?[{label:'Claude in Chrome',run:()=>call('world.open',{id:'chat',chooseBrowser:true})}]:[]),
   {label:'Losmaken van de taakbalk',run:()=>saveDock(layout.dock.filter(k=>k!==e.key))}];
  b.addEventListener('contextmenu',ev=>{ev.preventDefault();openPopup(b,b._menuEntries());});
  return b;
 });
 const others=windows.filter(w=>!entries.some(e=>owns(e,w)));
 const separator=key=>{const s=h('span',{class:'sep','aria-hidden':'true'});s.dataset.motionKey=key;return s;};
 const next=[startButton,separator('sep:main'),...pinned,...(others.length?[separator('sep:windows')]:[]),
  ...others.map(w=>{const b=button({name:w.title||w.appName||'Venster',img:w.icon,iconName:'grid',open:true,active:w.activated,onClick:()=>call('windows.activate',{id:w.id})});b.dataset.motionKey='window:'+w.id;return b;})];
 const added=[];
 const nodes=next.map(fresh=>{
  const existing=old.get(fresh.dataset.motionKey);
  if(!existing){added.push(fresh);return fresh;}
  old.delete(fresh.dataset.motionKey);
  const launching=existing.classList.contains('launching'),dragging=existing.classList.contains('dragging'),dragged=existing.dataset.dragged,translate=existing.style.translate;
  for(const a of [...existing.attributes])if(!fresh.hasAttribute(a.name))existing.removeAttribute(a.name);
  for(const a of fresh.attributes)existing.setAttribute(a.name,a.value);
  if(existing===labelAnchor){if(label)label.textContent=fresh.title;existing.title='';}
  if(launching)existing.classList.add('launching');
  if(dragging){existing.classList.add('dragging');existing.style.translate=translate;}
  if(dragged)existing.dataset.dragged=dragged;
  if(existing.innerHTML!==fresh.innerHTML)existing.replaceChildren(...fresh.childNodes);
  existing._onClick=fresh._onClick;existing._menuEntries=fresh._menuEntries;
  return existing;
 });
 // Bestaande knoppen houden hun identiteit, hover en focus; alleen echte wijzigingen bewegen.
 for(const b of old.values())b.remove();
 nodes.forEach((b,i)=>{if(bar.children[i]!==b)bar.insertBefore(b,bar.children[i]||null);});
 if(nodes.includes(focused)&&document.activeElement!==focused)focused.focus({preventScroll:true});
 for(const b of added)surfaceMotion(b,true,{duration:240,origin:'50% 100%'});
 for(const b of nodes){const r=before.get(b.dataset.motionKey);if(!r)continue;const dx=r.left-b.getBoundingClientRect().left;if(Math.abs(dx)>1)surfaceMotion(b,true,{curve:easing.travel,frames:[{transform:`translateX(${dx}px)`},{transform:'translateX(0)'}]});}
 for(const [key,b] of old){
  const r=before.get(key);b._stopDrag?.();b._launchDone?.();b.classList.remove('launching');b.inert=true;
  b.style.cssText=`position:fixed;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;pointer-events:none`;
  document.body.append(b);exiting++;heldWidth=Math.max(heldWidth,lastSize[0]);
  surfaceMotion(b,false,{duration:220}).then(()=>{b.remove();exiting--;if(!exiting)heldWidth=0;resize();});
 }
 if(labelAnchor&&!nodes.includes(labelAnchor))hideLabel();
 resize();
}
let lastSize=[0,0];
let exiting=0,heldWidth=0,label=null,labelAnchor=null,labelEpoch=0;
const closingSurfaces=new Set();
/** Surface size: the bar, plus room above it for a popup. */
function resize(){
 const overlays=[popup,label,...closingSurfaces].filter(Boolean);
 const width=Math.max(Math.ceil(bar.offsetWidth)+4,...overlays.map(el=>Math.ceil(el.offsetWidth)+8),exiting?heldWidth:0);
 const height=DOCK_HEIGHT+Math.max(0,...overlays.map(el=>Math.ceil(el.offsetHeight)+12));
 if(width===lastSize[0]&&height===lastSize[1])return Promise.resolve();
 lastSize=[width,height];
 return call('dock.size',{width,height}).catch(()=>{lastSize=[0,0];});
}
function saveLayout(){return call('layout.set',{layout}).then(l=>{layout=l;}).catch(e=>toast('Opslaan mislukt: '+e.message));}
function saveDock(dock){layout={...layout,dock};render();saveLayout();}

/** Drag a taskbar button sideways to give it another place. Followed on the whole page (no pointer capture in WebKitGTK). */
function reorderable(b,key){
 let x0=null,dragging=false;b.dataset.key=key;
 const stop=()=>{removeEventListener('pointermove',moveTo);removeEventListener('pointerup',end);removeEventListener('pointercancel',end);removeEventListener('blur',stop);x0=null;dragging=false;b.classList.remove('dragging');b.style.translate='';};
 b._stopDrag=stop;
 const moveTo=e=>{
  if(x0==null)return;const dx=e.clientX-x0;
  if(!dragging){if(Math.abs(dx)<6)return;dragging=true;b.classList.add('dragging');}
  b.style.translate=dx+'px 0';
 };
 const end=e=>{
  const moved=dragging;stop();if(!moved||e.type==='pointercancel')return;b.dataset.dragged='1';
  const others=[...bar.querySelectorAll('.item[data-key]')].filter(x=>x!==b);
  const keys=layout.dock.filter(k=>k!==key);let at=keys.length;
  others.forEach((x,i)=>{const r=x.getBoundingClientRect();if(at===keys.length&&e.clientX<r.left+r.width/2)at=i;});
  keys.splice(at,0,key);if(keys.join()!==layout.dock.join())saveDock(keys);
 };
 b.addEventListener('pointerdown',e=>{if(e.button!==0)return;x0=e.clientX;addEventListener('pointermove',moveTo);addEventListener('pointerup',end);addEventListener('pointercancel',end);addEventListener('blur',stop);});
}

// ----- popup menu (right click on a taskbar button) -----
function retire(el,duration){el.inert=true;closingSurfaces.add(el);surfaceMotion(el,false,{duration}).then(()=>{el.remove();closingSurfaces.delete(el);resize();});}
function closePopup(){const old=popup;popup=null;if(old)retire(old,200);}
function openPopup(anchor,entries,at){
 closePopup();hideLabel();
 popup=h('div',{class:'ctx',role:'menu','aria-label':'Acties'});
 for(const e of entries){const m=h('button',{type:'button',role:'menuitem'},e.label);m.addEventListener('click',()=>{closePopup();act(e.run);});popup.append(m);}
 document.body.append(popup);
 const opened=popup,grow=resize();
 // Position after the surface has grown: above the anchor, inside the surface.
 grow.then(()=>requestAnimationFrame(()=>{
  if(popup!==opened)return;const r=anchor.getBoundingClientRect(),w=popup.offsetWidth,hgt=popup.offsetHeight;
  const x=at?at[0]:r.left+r.width/2-w/2,y=at?at[1]:r.top-hgt-8;
  popup.style.left=Math.max(4,Math.min(x,innerWidth-w-4))+'px';popup.style.top=Math.max(4,Math.min(y,innerHeight-hgt-4))+'px';
  popup.style.visibility='visible';surfaceMotion(popup,true,{origin:`${r.left+r.width/2-parseFloat(popup.style.left)}px 100%`});revealItems(popup,'button');
  popup.querySelector('button')?.focus();
 }));
}

function labelled(b){
 b.addEventListener('pointerenter',()=>showLabel(b));b.addEventListener('focus',()=>showLabel(b));
 b.addEventListener('pointerleave',hideLabel);b.addEventListener('blur',hideLabel);
}
function hideLabel(){
 labelEpoch++;const old=label;label=null;
 if(labelAnchor){labelAnchor.title=labelAnchor.getAttribute('aria-label')?.replace(/ \((actief|geopend)\)$/,'')||'';labelAnchor=null;}
 if(old)retire(old,180);
}
function showLabel(anchor){
 if(popup||anchor===labelAnchor)return;hideLabel();const epoch=labelEpoch;
 labelAnchor=anchor;const text=anchor.title;anchor.title='';
 label=h('span',{class:'dock-label','aria-hidden':'true'},text);document.body.append(label);const opened=label;
 resize().then(()=>requestAnimationFrame(()=>{
  if(epoch!==labelEpoch||label!==opened||!anchor.isConnected)return;
  const r=anchor.getBoundingClientRect(),w=opened.offsetWidth;
  opened.style.left=Math.max(4,Math.min(r.left+r.width/2-w/2,innerWidth-w-4))+'px';opened.style.bottom=DOCK_HEIGHT+7+'px';opened.style.visibility='visible';
  surfaceMotion(opened,true,{duration:200,origin:'50% 100%'});
 }));
}

addEventListener('keydown',e=>{
 if(e.key==='Escape'&&popup){e.preventDefault();closePopup();return;}
 // Pijltjes omhoog/omlaag lopen door het open menu (toetsenbord), zoals in een gewoon menu.
 if(popup&&(e.key==='ArrowDown'||e.key==='ArrowUp')){
  e.preventDefault();const items=[...popup.querySelectorAll('button')],step=e.key==='ArrowDown'?1:-1,i=items.indexOf(document.activeElement);
  items[i<0?(step>0?0:items.length-1):(i+step+items.length)%items.length]?.focus();return;
 }
 if(!popup&&(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10'))&&document.activeElement?.classList.contains('item')){e.preventDefault();document.activeElement.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true}));}
});
addEventListener('pointerdown',e=>{
 if(popup&&!popup.contains(e.target))closePopup();
 if(startOpen&&!e.target.closest?.('.start-button'))call('surface.hide',{name:'start'}).catch(()=>{});
},true);
addEventListener('blur',()=>{closePopup();hideLabel();});

async function loadApps(){
 try{apps=await call('apps.list');}catch{}
 try{const b=await call('browser.list');browserIcon=b.apps.find(a=>a.id===b.default)?.icon||null;}catch{}
}
async function init(){
 const config=await call('config.get');applySettings({...config.settings,colors:config.world.colors});
 if(config.layout)layout=config.layout;
 await loadApps();
 try{windows=await call('windows.list');}catch{}
 render();window.__universePageReady?.();
}
// The shell sends the window list on every change of any window (also a title that ticks): only rebuild the bar
// when something it shows changed.
const shownWindows=l=>JSON.stringify((l||[]).map(w=>[w.id,w.title,w.appId,w.icon,w.activated,w.minimized]));
on('windows',list=>{const before=shownWindows(windows);windows=list||[];if(shownWindows(windows)!==before)render();});
on('layout',l=>{if(l){layout=l;render();}});
on('apps-changed',()=>loadApps().then(render));
on('start-state',open=>{startOpen=!!open;render();});
on('config',c=>applySettings({...c.settings,colors:c.world.colors}));
init();
