// 0.2.38 De sterrenhemel van de wereld en het inlogscherm (Jesse: 'maak de space nog beter dus nog mooier en echter').
// Eén tekenpad: lichte modus behoudt alle sterren, gloed en timing. Alleen de zachte neveltextuur heeft minder pixels.
// Geen CSS-filters of vervaging, alles plain 2D canvas; sterren en lichtsporen worden per kleur gegroepeerd.
//  - sterren in drie dieptelagen (parallax als de camera schuift of zoomt), met kleur naar temperatuur
//    (blauwwit, wit, geel, oranje) en veel zwakke, weinig heldere sterren, zoals echt;
//  - de helderste sterren twinkelen (eigen klein canvas, eigen klok) en hebben een zachte gloed met kruisje;
//  - een melkwegband met gekleurde nevels en donkere stofbanen, eenmaal gemaakt en daarna alleen verschoven;
//  - warp: bij inloggen/uitloggen/opstarten rekken de sterren uit tot lichtstrepen (snelheid van de camera).
const alpha=v=>Math.max(0,Math.min(1,v)).toFixed(3); // same as globe.js (no import: works without the page)

export const FOV=900;
export const KWALITEIT={
 vol:{elke:1,nevel:[1024,512],twinkel:90,fps:24,gloed:true},
 licht:{elke:1,nevel:[768,384],twinkel:90,fps:24,gloed:true},
};
export const kwaliteit=licht=>KWALITEIT[licht?'licht':'vol'];

// Temperatuurkleuren (RGB) en hoe vaak ze voorkomen.
export const KLEUREN=[[170,195,255],[210,224,255],[255,250,240],[255,226,170],[255,190,140]];
const KANS=[.12,.38,.28,.14,.08];
function rnd(seed){return ()=>(seed=(seed*16807)%2147483647)/2147483647;}
/** All stars: [x,y,z on the unit sphere, brightness .15..1, colour index, layer 0..2]. Fixed seed: always the same sky. */
export const STERREN=(()=>{
 const r=rnd(20251025),out=[];
 for(let i=0;i<9000;i++){
  const u=r()*2-1,t=r()*Math.PI*2,q=Math.sqrt(1-u*u);
  const b=.15+.85*Math.pow(r(),3.2); // power law: many faint stars, few bright ones
  let k=r(),ci=0;while(ci<KANS.length-1&&k>KANS[ci]){k-=KANS[ci];ci++;}
  out.push([q*Math.cos(t),u,q*Math.sin(t),b,ci,i%3]);
 }
 return out;
})();
/** Beide modi houden dezelfde sterren; de vaste groepen worden maar één keer opgebouwd. */
const cache=new Map();
const memo=(key,make)=>{if(!cache.has(key))cache.set(key,make());return cache.get(key);};
export const sterrenVoor=licht=>STERREN;
export const helderste=(licht,n=kwaliteit(licht).twinkel)=>memo('h'+licht+n,()=>sterrenVoor(licht).slice().sort((a,b)=>b[3]-a[3]).slice(0,n));
const helderSet=licht=>memo('hs'+licht,()=>new Set(helderste(licht)));

/** Screen position of a star (or null) for camera cam; parallax per layer when the camera moves or zooms. */
function sterCamera(cam,w,h){
 const cy=Math.cos(cam.yaw),sy=Math.sin(cam.yaw),cp=Math.cos(cam.pitch),sp=Math.sin(cam.pitch);
 return {cy,sy,cp,sp,w,h,dist:cam.dist||1650,tx:cam.tx||0,ty:cam.ty||0,tz:cam.tz||0};
}
function projectSter(s,cam){
 const {cy,sy,cp,sp,w,h}=cam;
 const [x,y,z,,,laag]=s;
 const x1=x*cy-z*sy,z1=x*sy+z*cy,y2=y*cp-z1*sp,z2=y*sp+z1*cp;if(z2<=.05)return null;
 const k=[0,.004,.011][laag],zoom=1+[0,.02,.06][laag]*(1650-(cam.dist||1650))/1650;
 const ox=-((cam.tx||0)*cy-(cam.tz||0)*sy)*k,oy=-(cam.ty||0)*k;
 return {x:w/2+(x1/z2*FOV)*zoom+ox,y:h/2+(y2/z2*FOV)*zoom+oy};
}
export function sterPunt(s,cam,w,h){return projectSter(s,sterCamera(cam,w,h));}

const sprites=new Map();
/** Soft glow sprite of a bright star (with a faint diffraction cross in the full version). */
export function sterSprite(ci,gloed){
 const key=ci+':'+gloed;if(sprites.has(key))return sprites.get(key);
 const S=gloed?32:12,cv=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(S,S):Object.assign(document.createElement('canvas'),{width:S,height:S});
 const c=cv.getContext('2d'),[R,G,B]=KLEUREN[ci],m=S/2;
 const g=c.createRadialGradient(m,m,0,m,m,m);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.18,`rgba(${R},${G},${B},.9)`);g.addColorStop(.45,`rgba(${R},${G},${B},.22)`);g.addColorStop(1,`rgba(${R},${G},${B},0)`);
 c.fillStyle=g;c.fillRect(0,0,S,S);
 if(gloed){c.strokeStyle=`rgba(${R},${G},${B},.35)`;c.lineWidth=1;c.beginPath();c.moveTo(m,1);c.lineTo(m,S-1);c.moveTo(1,m);c.lineTo(S-1,m);c.stroke();}
 sprites.set(key,cv);return cv;
}

const nevels=new Map();
/** The Milky Way band with coloured nebulae and dark dust, as a panorama (made once per quality). */
export function nevelTextuur(licht){
 const key=licht?'l':'v';if(nevels.has(key))return nevels.get(key);
 const [TW,TH]=kwaliteit(licht).nevel,r=rnd(777);
 const cv=typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(TW,TH):Object.assign(document.createElement('canvas'),{width:TW,height:TH});
 const c=cv.getContext('2d');
 const band=x=>TH*.5+Math.sin(x/TW*Math.PI*2)*TH*.16;
 const blob=(x,y,rad,col,a)=>{for(const dx of [-TW,0,TW]){const g=c.createRadialGradient(x+dx,y,0,x+dx,y,rad);g.addColorStop(0,`rgba(${col},${a})`);g.addColorStop(1,`rgba(${col},0)`);c.fillStyle=g;c.fillRect(x+dx-rad,y-rad,rad*2,rad*2);}};
 // the band: many soft clouds of starlight (same seed = same clouds in both qualities, only the resolution differs)
 for(let i=0;i<320;i++){const x=r()*TW,y=band(x)+(r()-.5)*TH*.14;blob(x,y,TH*(.03+r()*.08),r()<.6?'170,190,255':r()<.5?'255,225,195':'200,170,255',.03+r()*.035);}
 // coloured emission nebulae (red/magenta hydrogen, teal oxygen, violet)
 const kleur=['255,90,140','120,90,255','80,220,210','255,140,90'];
 for(let i=0;i<30;i++){const x=r()*TW,y=band(x)+(r()-.5)*TH*.3;blob(x,y,TH*(.05+r()*.12),kleur[i%4],.05+r()*.08);}
 // dark dust lanes along the band
 c.globalCompositeOperation='destination-out';
 for(let i=0;i<160;i++){const x=r()*TW,y=band(x)+(r()-.5)*TH*.04;blob(x,y,TH*(.01+r()*.025),'0,0,0',.12+r()*.16);}
 c.globalCompositeOperation='source-over';
 nevels.set(key,cv);return cv;
}
/** Draws the nebula panorama, turning with the camera (yaw shifts it sideways, pitch up/down). */
export function tekenNevel(c,cam,w,h,licht,sterkte=1){
 const tex=nevelTextuur(licht),SW=w*2.6,SH=h*1.8;
 const x0=-(((cam.yaw%(2*Math.PI))+2*Math.PI)%(2*Math.PI))/(2*Math.PI)*SW,y0=(h-SH)/2+Math.sin(cam.pitch-.42)*h*.6;
 c.globalAlpha=Math.max(0,Math.min(1,sterkte));
 for(let x=x0;x<w;x+=SW)c.drawImage(tex,x,y0,SW,SH);
 c.globalAlpha=1;
}
/** Draws the stars. warp (0..1) stretches them into light streaks away from the middle (login/logout/start). The
 *  brightest stars are left to the twinkle layer when `zonderHelder` is set. */
export function tekenSterren(c,cam,w,h,{licht=false,warp=0,zonderHelder=false}={}){
 const groepen=memo('groepen'+zonderHelder,()=>{
  const helder=zonderHelder?helderSet(false):null,m=new Map();
  for(const s of STERREN){if(helder?.has(s))continue;const key=s[4]*10+Math.min(9,Math.floor(s[3]*10));
   if(!m.has(key))m.set(key,[]);m.get(key).push(s);}
  return m;
 }),view=sterCamera(cam,w,h); // Eén set sin/cos per camera, niet 9000 keer per beeld.
 c.lineCap='round';
 for(const [key,g] of groepen){
  const [R,G,B]=KLEUREN[Math.floor(key/10)],b=(key%10+.5)/10;
  if(warp>.02){
   c.strokeStyle=`rgba(${R},${G},${B},${alpha(b*(.6+.4*warp))})`;c.lineWidth=.6+b*1.4;c.beginPath();
   for(const s of g){const p=projectSter(s,view);if(!p||p.x<-40||p.y<-40||p.x>w+40||p.y>h+40)continue;
    const dx=p.x-w/2,dy=p.y-h/2,l=warp*.35*(1+s[5]*.6);c.moveTo(p.x,p.y);c.lineTo(p.x+dx*l,p.y+dy*l);}
   c.stroke();
  }else{
   c.fillStyle=`rgba(${R},${G},${B},${alpha(b)})`;c.beginPath();
   for(const s of g){const p=projectSter(s,view);if(!p||p.x<-40||p.y<-40||p.x>w+40||p.y>h+40)continue;
    const r=.45+s[3]*1.1+(s[5]===2?.2:0);c.moveTo(p.x+r,p.y);c.arc(p.x,p.y,r,0,7);}
   c.fill();
  }
 }
}
/** Twinkle factor of star i at time t (s): slow, irregular, never fully dark. */
export const twinkel=(i,t)=>.62+.38*(.6*Math.sin(t*(1.3+(i%7)*.37)+i)+.4*Math.sin(t*(3.1+(i%5)*.53)+i*2.3));
// Travel = cubic-bezier(.45,0,.2,1); slechts tweemaal per beeld van de zeldzame vallende ster.
function reis(k){
 if(k<=0||k>=1)return Math.max(0,Math.min(1,k));let lo=0,hi=1,t=k;
 for(let i=0;i<12;i++){t=(lo+hi)/2;const x=3*(1-t)*(1-t)*t*.45+3*(1-t)*t*t*.2+t*t*t;if(x<k)lo=t;else hi=t;}
 return t*t*(3-2*t);
}
// Zachte wolk en kort lichtspoor: éénmaal getekend, daarna alleen verplaatst/geschaald.
function hemelSprites(){return memo('hemel-sprites',()=>{
 const cloud=document.createElement('canvas'),trail=document.createElement('canvas');cloud.width=384;cloud.height=256;trail.width=128;trail.height=12;
 const c=cloud.getContext('2d');
 for(const [x,y,r,col] of [[130,140,115,'65,160,190'],[240,100,110,'120,85,190'],[200,170,80,'75,140,180']]){
  const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${col},.4)`);g.addColorStop(1,`rgba(${col},0)`);c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);
 }
 const t=trail.getContext('2d'),g=t.createLinearGradient(0,0,128,0);g.addColorStop(0,'#8fdcff00');g.addColorStop(.7,'#8fdcff80');g.addColorStop(1,'#effcff');
 t.fillStyle=g;t.globalAlpha=.2;t.fillRect(0,1,128,10);t.globalAlpha=1;t.fillRect(0,5,128,2);
 return {cloud,trail};
});}
/** Helderste sterren, rustige neveldrift en zelden een vallende ster, in één klok voor beide grafische modi. */
export function twinkelLaag(canvas,getCam,{licht=false,scale=()=>1,actief=()=>true}={}){
 const q=kwaliteit(licht),lijst=helderste(licht),sprites=KLEUREN.map((_,i)=>sterSprite(i,true)),{cloud,trail}=hemelSprites();
 const media=typeof matchMedia==='function'?matchMedia('(prefers-reduced-motion: reduce)'):null;
 let raf=0,running=false,last=-Infinity,warp=0,reduced=false;
 const quiet=()=>reduced||media?.matches||document.documentElement.classList.contains?.('reduce-motion')||document.documentElement.classList.contains?.('no-motion');
 function draw(t=performance.now()/1000){
  const w=innerWidth,h=innerHeight,dpr=scale(w,h);
  if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
  const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
  const stil=quiet(),cam=sterCamera(getCam(),w,h);if(stil)t=0;
  if(!stil&&warp<.02){
   c.globalAlpha=.12;c.drawImage(cloud,w*.18+Math.sin(t/61)*w*.012,h*.08+Math.sin(t/79)*h*.012,w*.65,h*.65);
  }
  lijst.forEach((s,i)=>{
   const p=projectSter(s,cam);if(!p)return;
   if(!stil&&warp<.02){const depth=1+s[5]*.7;p.x+=Math.sin(t/53+s[5])*.9*depth;p.y+=Math.sin(t/67+s[5])*.6*depth;}
   const f=stil ? .85 : warp>.02?1:twinkel(i,t),size=9+s[3]*12;
   c.globalAlpha=Math.min(1,s[3]*f*1.15);
   if(warp>.02){const [R,G,B]=KLEUREN[s[4]],dx=p.x-w/2,dy=p.y-h/2,l=warp*.45;c.strokeStyle=`rgb(${R},${G},${B})`;c.lineWidth=1.6;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(p.x+dx*l,p.y+dy*l);c.stroke();}
   else c.drawImage(sprites[s[4]],p.x-size/2,p.y-size/2,size,size);
  });
  // Eens per 47 s; begin/einde vallen ook bij 6 fps zacht weg. Geen opgestapelde timers.
  const age=((t-23)%47+47)%47;
  if(!stil&&warp<.02&&t>=23&&age<1.8){
   const k=age/1.8,e=reis(k),prev=reis(Math.max(0,k-.045)),dx=w*.25,dy=h*.16;
   const x=w*.55+dx*e,y=h*.14+dy*e,len=Math.max(2,Math.hypot(dx,dy)*(e-prev));
   c.save();c.globalAlpha=Math.sin(k*Math.PI)*.7;c.translate(x,y);c.rotate(Math.atan2(dy,dx));c.drawImage(trail,-len,-3,len,6);c.drawImage(sprites[1],-5,-5,10,10);c.restore();
  }
  c.globalAlpha=1;
 }
 function tick(now){raf=0;if(!running)return;if(now-last>=1000/q.fps){last=now;if(!document.hidden&&actief()&&!quiet())draw(now/1000);}raf=requestAnimationFrame(tick);}
 function stop(){running=false;if(raf)cancelAnimationFrame(raf);raf=0;removeEventListener('pagehide',stop);}
 return {draw,start(){if(running)return;running=true;last=-Infinity;draw();addEventListener('pagehide',stop);raf=requestAnimationFrame(tick);},stop,
  setWarp(v){warp=v;},setReduced(v){reduced=!!v;},fps:q.fps,aantal:lijst.length};
}
