// Shared clock for the full-screen animations (login, logout, lock, desktop start). Axel (14 Oct): every pc must run
// them smoothly, and they may never hang or stutter. The rules:
//  - an animation always ends: a timer finishes it even when no frame comes (hidden window, stalled renderer);
//  - it follows the clock: a slow frame skips ahead instead of stretching the animation;
//  - on a slow pc it switches to the light version (fewer particles, fewer pixels) instead of being skipped;
//  - even a very slow frame follows the clock, without ending the effect prematurely.
// Before 14 Oct two frames over 250 ms skipped every later animation, so a VM or an old pc never saw them.
const params=new URLSearchParams(location.search);
let light=params.get('gfx')==='soft'||params.get('gfx')==='licht'||(navigator.hardwareConcurrency||2)<=2;
/** True on weak hardware or after slow frames: callers draw fewer particles and use fewer pixels. */
export const isLight=()=>light;
/** Runs frame(t) with t from 0 to 1 over `duration` ms; resolves after frame(1), at the latest shortly after `duration`. */
export function animate(duration,frame){
 return new Promise(resolve=>{
  const t0=performance.now();let last=0,slow=0,done=false,drawnEnd=false,raf=0;
  const draw=t=>{drawnEnd=t>=1;try{frame(t);}catch(e){console.error(e);finish();}};
  const finish=()=>{if(done)return;done=true;clearTimeout(timer);if(typeof cancelAnimationFrame==='function')cancelAnimationFrame(raf);if(!drawnEnd)draw(1);resolve();};
  const timer=setTimeout(finish,duration+80);
  const step=now=>{
   if(done)return;
   // The first frame often waits for the page to settle: only gaps between our own frames count.
   if(last){const gap=now-last;if(gap>120&&++slow>=2)light=true;}
   last=now;
   const t=Math.max(0,Math.min(1,(now-t0)/duration));draw(t);
   if(done)return;
   if(t<1)raf=requestAnimationFrame(step);else finish();
  };
  raf=requestAnimationFrame(step);
 });
}

// Kleine oppervlakken delen dezelfde beweging; kwaliteit/licht verandert hier nooit het beeld.
export const easing={enter:'cubic-bezier(.22,.8,.24,1)',exit:'cubic-bezier(.5,0,.75,0)',travel:'cubic-bezier(.45,0,.2,1)'};
const elementEffects=new WeakMap();
export const uiMotionAllowed=()=>!document.documentElement.classList.contains('reduce-motion')&&!document.documentElement.classList.contains('no-motion')&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
/** Browser-tijdlijn, met een vaste eindtijd en opruimen bij omkeren/een verborgen WebView. */
export function surfaceMotion(el,show,{duration=240,origin,frames,curve}={}){
 if(!el)return Promise.resolve();
 const previous=elementEffects.get(el);
 // Alleen bij omkeren één stijlmeting: sluit verder vanaf het werkelijk zichtbare beeld.
 const computed=previous&&typeof getComputedStyle==='function'?getComputedStyle(el):null;
 const interrupted=computed?{opacity:computed.opacity,transform:computed.transform}:null;
 previous?.();
 if(!uiMotionAllowed()||!el.animate)return Promise.resolve();
 if(origin)el.style.transformOrigin=origin;
 return new Promise(resolve=>{
  let animation,timer,done=false;
  const finish=()=>{if(done)return;done=true;clearTimeout(timer);animation?.cancel();if(elementEffects.get(el)===finish)elementEffects.delete(el);resolve();};
  elementEffects.set(el,finish);
  const poses=frames?[...frames]:(show?[
   {opacity:0,transform:'translateY(8px) scale(.96)',offset:0},
   {opacity:1,transform:'translateY(0) scale(1.018)',offset:.78},
   {opacity:1,transform:'translateY(0) scale(1)',offset:1}
  ]:[{opacity:1,transform:'translateY(0) scale(1)'},{opacity:0,transform:'translateY(6px) scale(.96)'}]);
  if(interrupted)poses[0]={...poses[0],...interrupted};
  try{
   animation=el.animate(poses,{duration,easing:curve||(show?easing.enter:easing.exit),fill:'both'});
   animation.onfinish=finish;animation.oncancel=finish;
   timer=setTimeout(finish,duration+80);
  }catch{finish();}
 });
}
/** Beperkte spreiding: ook een lange lijst is binnen 260 ms volledig leesbaar. */
export function revealItems(container,selector){
 const items=[...container.querySelectorAll(selector)];
 items.forEach((el,i)=>{
  const delay=Math.min(i,6)*12;
  surfaceMotion(el,true,{duration:240,frames:[
   {opacity:0,transform:'translateY(5px)',offset:0},
   {opacity:0,transform:'translateY(5px)',offset:delay/240},
   {opacity:1,transform:'translateY(0)',offset:1}
  ]});
 });
}
/** Een enkele ademhaling en uitdovende lichtring; nooit een tweede vensterportaal of geluid. */
export function launchFeedback(el){
 if(!el||!uiMotionAllowed())return;
 el._launchDone?.();
 const sphere=el.querySelector('.sp-planet,img,.icon')||el,r=sphere.getBoundingClientRect();
 const ring=document.createElement('span');ring.className='motion-launch-ring';ring.setAttribute('aria-hidden','true');
 const size=Math.max(r.width,r.height);
 ring.style.cssText=`position:fixed;inset:auto;left:${r.left+r.width/2-size/2}px;top:${r.top+r.height/2-size/2}px;width:${size}px;height:${size}px;z-index:30`;
 document.body.append(ring);
 let finished=false;
 const done=()=>{
  if(finished)return;finished=true;elementEffects.get(ring)?.();elementEffects.get(sphere)?.();ring.remove();
  if(el._launchDone===done)delete el._launchDone;
 };el._launchDone=done;
 surfaceMotion(sphere,true,{duration:720,frames:[
  {transform:'scale(1)',offset:0},{transform:'scale(1.03)',offset:.3},
  {transform:'scale(.995)',offset:.82},{transform:'scale(1)',offset:1}
 ]});
 surfaceMotion(ring,true,{duration:720,frames:[
  {opacity:0,transform:'scale(.85)',offset:0},{opacity:.85,transform:'scale(1.08)',offset:.22},
  {opacity:0,transform:'scale(1.85)',offset:1}
 ]}).then(done);
}
