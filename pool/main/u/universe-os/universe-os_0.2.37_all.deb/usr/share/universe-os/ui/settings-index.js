// All settings pages of the Controlecentrum, with search words. Used by the control centre and by search.
export const SETTINGS=[
 {id:'appearance',name:'Weergave en toegankelijkheid',icon:'display',words:'animaties beweging verminderen schaal tekst grootte lettergrootte toegankelijkheid reizen thema'},
 {id:'network',name:'Netwerk en wifi',icon:'wifi',words:'internet wifi wlan draadloos ethernet kabel vpn verbinding'},
 {id:'sound',name:'Geluid en microfoon',icon:'volume',words:'volume luidspreker koptelefoon microfoon audio dempen systeemgeluiden geluiden inloggen meldingen'},
 {id:'displays',name:'Beeldschermen',icon:'display',words:'scherm resolutie monitor meerdere beeldschermen schaal'},
 {id:'bluetooth',name:'Bluetooth',icon:'bluetooth',words:'bluetooth koppelen koptelefoon muis'},
 {id:'keyboard',name:'Taal en toetsenbord',icon:'keyboard',words:'taal nederlands engels toetsenbord indeling qwerty azerty internationaal testen tekens'},
 {id:'mouse',name:'Muis en touchpad',icon:'mouse',words:'muis touchpad snelheid klikken scrollen'},
 {id:'datetime',name:'Datum en tijd',icon:'clock',words:'tijdzone klok datum amsterdam'},
 {id:'power',name:'Energie',icon:'battery',words:'batterij energie slaapstand vergrendelen scherm uit'},
 {id:'users',name:'Gebruikers',icon:'user',words:'gebruikers beheerder wachtwoord toevoegen verwijderen sudo gebruikersaccount'},
 {id:'accounts',name:'Accounts',icon:'mail',words:'accounts google microsoft mail e-mail agenda imap smtp caldav oauth koppelen scherm bedienen ai assistent chrome gmail outlook browser'},
 {id:'shortcuts',name:'Sneltoetsen',icon:'keyboard',words:'sneltoetsen sneltoets overzicht help f1 toetsencombinaties windows super alt tab'},
 {id:'updates',name:'Software en updates',icon:'update',words:'updates bijwerken beveiliging herstarten pakketten apt'},
 {id:'security',name:'Beveiliging',icon:'shield',words:'firewall privacy beveiliging ufw brein herinneringen vergeten exporteren tweede brein nevel ghost modus logboek wolk'},
 {id:'ai',name:'AI',icon:'chat',words:'ai claude code chatgpt openai codex gemini google ollama opencode goose lokaal model assistent installeren inloggen personage bureaublad sleutel plugins lessen gebruik headroom omniroute litellm tokens besparen automatisch toestaan frontend zen god rustig autonomie'},
 {id:'about',name:'Over Universe OS',icon:'info',words:'versie systeem informatie licenties hardware'}
];
